import React from "react";
import "./hero.css";
import girl from "../../Assets/girl.png";
import cvlogo from "../../Assets/newlogo.png";
// import sequenceLogo from "../../Assets/logo.png";

function Hero() {
  return (
    <div class="hero">
      <div class="left-hero">
        <div class="left-read">
          <img src={cvlogo} class="cv" />
          <h1>Welcome to ComplyVantage</h1>
          <p>
            We set very high-quality standards when it comes to Engineering.
            With years of experience, we have learned how to help our partners
            build the right solutions in the right way.
          </p>
        </div>
        <div class="left-upload">
          <input
            type="file"
            class="inputbutton"
            icon="pi pi-upload"
            accept=".zip"
          />
          <button class="submitButton">Submit</button>
        </div>
      </div>
      <div class="right-hero">
        <img class="heroImage" src={girl} alt="hero" />
      </div>
    </div>
  );
}

export default Hero;
