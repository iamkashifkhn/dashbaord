import React from "react";
import "./navbar.css";
import logo from "../../Assets/newlogo.png";
import { Link } from "react-router-dom";
function Navbar() {
  return (
    <div>
      <header>
        <a href="#" class="brand-logo">
          <img class="cvlogo" src={logo} alt="Comply Vantage" />
        </a>
        <ul class="navlinks">
          <li>
            <a href="#"> Home </a>
          </li>
          <li>
            <a href="#"> Services </a>
          </li>
          <li>
            <a href="#"> About </a>
          </li>
          <li>
            <a href="#"> Contact </a>
          </li>
          <Link to="/login" className="navigation_link">
            Login
          </Link>
        </ul>
      </header>
    </div>
  );
}

export default Navbar;
