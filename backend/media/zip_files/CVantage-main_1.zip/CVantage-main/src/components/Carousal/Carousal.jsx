import React from "react";
import Image1 from "../../Assets/carousal/1.png";
import Image2 from "../../Assets/carousal/2.png";
import Image3 from "../../Assets/carousal/3.png";

const Carousal = () => {
  return (
    <div
      id="carouselExampleCaptions"
      className="carousel slide"
      data-bs-ride="carousel"
    >
      <div class="carousel-indicators">
        <button
          type="button"
          data-bs-target="#carouselExampleCaptions"
          data-bs-slide-to="0"
          className="active"
          aria-current="true"
          aria-label="Slide 1"
        ></button>
        <button
          type="button"
          data-bs-target="#carouselExampleCaptions"
          data-bs-slide-to="1"
          aria-label="Slide 2"
        ></button>
        <button
          type="button"
          data-bs-target="#carouselExampleCaptions"
          data-bs-slide-to="2"
          aria-label="Slide 3"
        ></button>
      </div>
      <div className="carousel-inner">
        <div className="carousel-item active" data-bs-interval="2000">
          <div className="carousal-image">
            <img src={Image1} alt="..." />
          </div>
          <div className="carousel-caption">
            <h5>ComplyVantage - simply your software licensing compliance!!</h5>
          </div>
        </div>
        <div className="carousel-item" data-bs-interval="2000">
          <div className="carousal-image">
            <img src={Image2} class="d-block" alt="..." />
          </div>

          <div className="carousel-caption">
            <h5>
              Some representative placeholder content for the second slide.
            </h5>
          </div>
        </div>
        <div className="carousel-item" data-bs-interval="2000">
          <div className="carousal-image">
            <img src={Image3} class="d-block" alt="..." />
          </div>

          <div className="carousel-caption">
            <h5>
              Some representative placeholder content for the third slide.
            </h5>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Carousal;
