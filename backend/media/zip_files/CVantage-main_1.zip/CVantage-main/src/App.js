import "./App.css";
import React from "react";
import AppRouter from "../src/views/AppRouter/AppRouter";

const App = () => {
  return (
    <div className="App">
      <AppRouter />
    </div>
  );
};

export default App;
