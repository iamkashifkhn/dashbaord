import React from "react";
import "./signup.css";
import { useState } from "react";
import Carousal from "../../components/Carousal/Carousal";
import { Checkbox } from "primereact/checkbox";
import { Link } from "react-router-dom";
import googleImage from "../../Assets/googlelogo.svg";
import logo from "../../Assets/newlogo.png";
import sequencelogo from "../../Assets/logo.png";
import {AiFillLock, AiOutlineUser} from '../../../node_modules/react-icons/ai'
import {IoIosEye} from 'react-icons/io'


const SignUP = () => {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [passwordShown, setPasswordShown] = useState(false);

  const togglePassword = (event) => {
    // When the handler is invoked
    // inverse the boolean state of passwordShown
    setPasswordShown(!passwordShown);
    event.preventDefault();
  };

  return (
    <div className="main-signup">
      <header>
        <a href="#" class="brand-logo">
          <img class="cvlogo" src={logo} alt="Comply Vantage" />
        </a>
        <ul>
          <Link to="/" className="goto-homepage">
            Go to Homepage
          </Link>
        </ul>
      </header>
      <div className="inner-main-signup-page">
        {/* Signup form on left side */}
        <div className="left">
          <div className="left-inner">
            <form>
              <h2 className="mb-3 right-heading"> Sign Up for an Account </h2>
              <div className="input-group mb-3">
              <span class="input-group-text" id="basic-addon1"><AiOutlineUser/></span>
                <input
                  type="name"
                  className="form-control"
                  id="name"
                  aria-describedby="emailHelp"
                  placeholder="Full Name"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                />
              </div>
              <div className="input-group mb-3">
              <span class="input-group-text" id="basic-addon1">@</span>
                <input
                  value={email}
                  type="email"
                  id="email"
                  placeholder="Email Address"
                  className="form-control"
                  onChange={(e) => setEmail(e.target.value)}
                />
              </div>
              <div className="input-group mb-3">
              <span class="input-group-text" id="basic-addon1"><AiFillLock/></span>
                <input
                  value={password}
                  type={passwordShown? 'text' : 'password'}
                  id="password"
                  placeholder="Password"
                  className="form-control"
                  onChange={(e) => setPassword(e.target.value)}
                />
                  <button class="input-group-text" 
                  style={{backgroundColor:'white', borderLeft:'none'}} 
                  id="basic-addon1"
                  onClick={togglePassword}
                  >
                  <IoIosEye/>
                  </button>
              </div>
              <div className="field-checkbox mb-3">
                <Checkbox

                />
                <label htmlFor="binary">
                  I agree with
                  <span>
                    <a href="https://www.google.com"> Terms </a>
                  </span>
                  and
                  <span>
                    <a href="https://www.sequence.com"> Policy</a>
                  </span>
                </label>
              </div>
              <div className="form-group mb-3">
                <button className="btn btn-primary">Sign up</button>
              </div>
              <div className="form-group">
                <button className="btn btn-primary signin-google">
                  <img
                    src={googleImage}
                    alt="signin with google"
                    className="signinwithgoogle"
                  />
                  Sign Up with Google
                </button>
              </div>
              <p className="mt-2">
                Already Have an account? &nbsp;
                <Link to="/login" className="nav_link">
                  Login
                </Link>
              </p>
            </form>
            <div className="powered-by">
              <p>Powered by</p>
              <img src={sequencelogo} alt="Sequenxe" />
            </div>
          </div>
        </div>
        {/* Carousal on right side */}
        <div className="right">
          <Carousal />
        </div>
      </div>
    </div>
  );
};

export default SignUP;
