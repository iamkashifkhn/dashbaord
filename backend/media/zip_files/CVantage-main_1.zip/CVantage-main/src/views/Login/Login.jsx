import React from "react";
import "./login.css";
import { useState } from "react";
import Carousal from "../../components/Carousal/Carousal";
import { Checkbox } from "../../../node_modules/primereact/checkbox";
import { Link } from "react-router-dom";
import googleImage from "../../Assets/googlelogo.svg";
import logo from "../../Assets/newlogo.png";
import sequencelogo from "../../Assets/logo.png";
import { AiFillLock } from "react-icons/ai";
import {IoIosEye} from 'react-icons/io'


const Login = () => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [passwordShown, setPasswordShown] = useState(false);

  const togglePassword = (event) => {
    // When the handler is invoked
    // inverse the boolean state of passwordShown
    setPasswordShown(!passwordShown);
    event.preventDefault();
  };

  return (
    <div>
      <div className="main-login">
        <header>
          <a href="#" class="brand-logo">
            <img class="cvlogo" src={logo} alt="Comply Vantage" />
          </a>
          <ul>
            <Link to="/" className="goto-homepage">
              Go to Homepage
            </Link>
          </ul>
        </header>
        {/* Carousal for the login page on left side */}
        <div className="inner-main-login-page">
          <div className="left">
            <Carousal />
          </div>

          {/* Login form on right side */}
          <div className="right">
            <div className="right-inner">
              <form>
                <h2 className="mb-3 right-heading"> Login to your Account</h2>
                <div className="input-group mb-3">
                <span class="input-group-text" id="basic-addon1">@</span>
                  <input
                    value={email}
                    type="email"
                    id="email"
                    placeholder="Email Address"
                    className="form-control"
                    onChange={(e) => setEmail(e.target.value)}
                  />
                </div>
                <div className="input-group mb-3">
                <span class="input-group-text" id="basic-addon1"><AiFillLock/></span>
                  <input
                    value={password}
                    type={passwordShown ? "text" : "password"}
                    id="password"
                    placeholder="Password"
                    className="form-control"
                    onChange={(e) => setPassword(e.target.value)}
                  />
                  <button class="input-group-text" 
                  style={{backgroundColor:'white', borderLeft:'none'}} 
                  id="basic-addon1"
                  onClick={togglePassword}
                  >
                  <IoIosEye/>
                  </button>
                </div>
                <div className="field-checkbox mb-3">
                  <Checkbox
                    inputId="binary"
                  />
                  <label htmlFor="binary">Remember Me</label>
                </div>
                <div className="form-group mb-3">
                  <button className="btn btn-primary">Signin</button>
                </div>
                <div className="form-group">
                  <button className="btn btn-primary signin-google">
                    <img
                      src={googleImage}
                      alt="loginwithGoogle"
                      className="signinwithgoogle"
                    />
                    Sign in with <span style={{fontWeight:'bold'}}>Google </span>
                  </button>
                </div>
                <p className="mt-2">
                  Don't have an account? &nbsp;
                  <Link to="/signup" className="nav_link">
                    Sign Up
                  </Link>
                </p>
              </form>
              <div className="powered-by">
                <p>Powered by</p>
                <img src={sequencelogo} alt="Sequenxe" />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Login;
